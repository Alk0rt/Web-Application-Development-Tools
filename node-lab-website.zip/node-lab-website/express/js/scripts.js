document.addEventListener("DOMContentLoaded", function() {

    const heading = document.querySelector("h2.w3-wide");
    heading.addEventListener("mouseover", function() {
        heading.style.color = "blue";
    });
    heading.addEventListener("mouseout", function() {
        heading.style.color = "#fd0000";
    });

    const buttons = document.querySelectorAll(".w3-button");
    buttons.forEach(button => {
        button.addEventListener("click", function() {
            button.classList.add("clicked");
            setTimeout(() => {
                button.classList.remove("clicked");
            }, 300); 
        });
    });
});
